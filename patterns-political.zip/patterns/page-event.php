<?php
/**
 * Title:Page Event
 * Slug: patterns-political/page-event
 * Categories: page
 * Keywords: Page
 * Post Types: page
 * Description: A layout that displays event page.
 *
 * @package    Patterns_Political
 * @subpackage Patterns_Political/patterns
 * @since      1.0.0
 */

?>
<!-- wp:pattern {"slug":"patterns-political/featured-section-3"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-2"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-4"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-7"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-6"} /-->
