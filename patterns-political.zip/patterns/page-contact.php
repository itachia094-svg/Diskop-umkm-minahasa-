<?php
/**
 * Title: Page Contact
 * Slug: patterns-political/page-contact
 * Categories: page
 * Keywords: Page
 * Post Types: page
 * Description: A layout that displays contact page.
 *
 * @package    Patterns_Political
 * @subpackage Patterns_Political/patterns
 * @since      1.0.0
 */
?>
<!-- wp:pattern {"slug":"patterns-political/featured-section-9"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-10"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-11"} /-->
