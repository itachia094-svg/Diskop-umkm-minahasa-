<?php
/**
 * Title: Page About
 * Slug: patterns-political/page-about
 * Categories: page
 * Keywords: Page
 * Post Types: page
 * Description: A layout that displays about page.
 *
 * @package    Patterns_Political
 * @subpackage Patterns_Political/patterns
 * @since      1.0.0
 */

?>
<!-- wp:pattern {"slug":"patterns-political/featured-section-1"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-2"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-3"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-7"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-4"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-5"} /-->
<!-- wp:pattern {"slug":"patterns-political/featured-section-6"} /-->
