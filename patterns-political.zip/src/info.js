import './admin/info/index.js';
